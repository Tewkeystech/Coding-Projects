﻿namespace Pizza_Parlor_Pricer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSupreme = new System.Windows.Forms.Button();
            this.btnPepAndMush = new System.Windows.Forms.Button();
            this.btnHawaiin = new System.Windows.Forms.Button();
            this.btnVeg = new System.Windows.Forms.Button();
            this.cbxExtraCheese = new System.Windows.Forms.CheckBox();
            this.cbxPepperoni = new System.Windows.Forms.CheckBox();
            this.cbxSausage = new System.Windows.Forms.CheckBox();
            this.cbxCanBacon = new System.Windows.Forms.CheckBox();
            this.cbxPineapple = new System.Windows.Forms.CheckBox();
            this.cbxMushrooms = new System.Windows.Forms.CheckBox();
            this.cbxBellPepp = new System.Windows.Forms.CheckBox();
            this.cbxOnions = new System.Windows.Forms.CheckBox();
            this.cbxOlives = new System.Windows.Forms.CheckBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.rdbTen = new System.Windows.Forms.RadioButton();
            this.rdbFourteen = new System.Windows.Forms.RadioButton();
            this.rdbEightteen = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Salmon;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Location = new System.Drawing.Point(170, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 312);
            this.label1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Salmon;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Location = new System.Drawing.Point(276, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 312);
            this.label2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Salmon;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label3.Location = new System.Drawing.Point(382, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 312);
            this.label3.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(64, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Choose a size:";
            // 
            // btnSupreme
            // 
            this.btnSupreme.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSupreme.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSupreme.Location = new System.Drawing.Point(506, 51);
            this.btnSupreme.Name = "btnSupreme";
            this.btnSupreme.Size = new System.Drawing.Size(140, 60);
            this.btnSupreme.TabIndex = 4;
            this.btnSupreme.Text = "Supreme";
            this.btnSupreme.UseVisualStyleBackColor = false;
            this.btnSupreme.Click += new System.EventHandler(this.btnSupreme_Click);
            // 
            // btnPepAndMush
            // 
            this.btnPepAndMush.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnPepAndMush.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPepAndMush.Location = new System.Drawing.Point(506, 117);
            this.btnPepAndMush.Name = "btnPepAndMush";
            this.btnPepAndMush.Size = new System.Drawing.Size(140, 60);
            this.btnPepAndMush.TabIndex = 5;
            this.btnPepAndMush.Text = "Pepperoni and Mushroom";
            this.btnPepAndMush.UseVisualStyleBackColor = false;
            this.btnPepAndMush.Click += new System.EventHandler(this.btnPepAndMush_Click);
            // 
            // btnHawaiin
            // 
            this.btnHawaiin.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnHawaiin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHawaiin.Location = new System.Drawing.Point(506, 183);
            this.btnHawaiin.Name = "btnHawaiin";
            this.btnHawaiin.Size = new System.Drawing.Size(140, 60);
            this.btnHawaiin.TabIndex = 6;
            this.btnHawaiin.Text = "Hawaiian";
            this.btnHawaiin.UseVisualStyleBackColor = false;
            this.btnHawaiin.Click += new System.EventHandler(this.btnHawaiin_Click);
            // 
            // btnVeg
            // 
            this.btnVeg.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnVeg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVeg.Location = new System.Drawing.Point(506, 249);
            this.btnVeg.Name = "btnVeg";
            this.btnVeg.Size = new System.Drawing.Size(140, 60);
            this.btnVeg.TabIndex = 7;
            this.btnVeg.Text = "Vegetarian";
            this.btnVeg.UseVisualStyleBackColor = false;
            this.btnVeg.Click += new System.EventHandler(this.btnVeg_Click);
            // 
            // cbxExtraCheese
            // 
            this.cbxExtraCheese.AutoSize = true;
            this.cbxExtraCheese.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxExtraCheese.Location = new System.Drawing.Point(50, 106);
            this.cbxExtraCheese.Name = "cbxExtraCheese";
            this.cbxExtraCheese.Size = new System.Drawing.Size(87, 17);
            this.cbxExtraCheese.TabIndex = 8;
            this.cbxExtraCheese.Text = "Extra Cheese";
            this.cbxExtraCheese.UseVisualStyleBackColor = true;
            this.cbxExtraCheese.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // cbxPepperoni
            // 
            this.cbxPepperoni.AutoSize = true;
            this.cbxPepperoni.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxPepperoni.Location = new System.Drawing.Point(50, 129);
            this.cbxPepperoni.Name = "cbxPepperoni";
            this.cbxPepperoni.Size = new System.Drawing.Size(72, 17);
            this.cbxPepperoni.TabIndex = 9;
            this.cbxPepperoni.Text = "Pepperoni";
            this.cbxPepperoni.UseVisualStyleBackColor = true;
            this.cbxPepperoni.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // cbxSausage
            // 
            this.cbxSausage.AutoSize = true;
            this.cbxSausage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxSausage.Location = new System.Drawing.Point(50, 152);
            this.cbxSausage.Name = "cbxSausage";
            this.cbxSausage.Size = new System.Drawing.Size(66, 17);
            this.cbxSausage.TabIndex = 10;
            this.cbxSausage.Text = "Sausage";
            this.cbxSausage.UseVisualStyleBackColor = true;
            this.cbxSausage.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // cbxCanBacon
            // 
            this.cbxCanBacon.AutoSize = true;
            this.cbxCanBacon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxCanBacon.Location = new System.Drawing.Point(50, 175);
            this.cbxCanBacon.Name = "cbxCanBacon";
            this.cbxCanBacon.Size = new System.Drawing.Size(103, 17);
            this.cbxCanBacon.TabIndex = 11;
            this.cbxCanBacon.Text = "Canadian Bacon";
            this.cbxCanBacon.UseVisualStyleBackColor = true;
            this.cbxCanBacon.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // cbxPineapple
            // 
            this.cbxPineapple.AutoSize = true;
            this.cbxPineapple.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxPineapple.Location = new System.Drawing.Point(50, 198);
            this.cbxPineapple.Name = "cbxPineapple";
            this.cbxPineapple.Size = new System.Drawing.Size(71, 17);
            this.cbxPineapple.TabIndex = 12;
            this.cbxPineapple.Text = "Pineapple";
            this.cbxPineapple.UseVisualStyleBackColor = true;
            this.cbxPineapple.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // cbxMushrooms
            // 
            this.cbxMushrooms.AutoSize = true;
            this.cbxMushrooms.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxMushrooms.Location = new System.Drawing.Point(50, 221);
            this.cbxMushrooms.Name = "cbxMushrooms";
            this.cbxMushrooms.Size = new System.Drawing.Size(78, 17);
            this.cbxMushrooms.TabIndex = 13;
            this.cbxMushrooms.Text = "Mushrooms";
            this.cbxMushrooms.UseVisualStyleBackColor = true;
            this.cbxMushrooms.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // cbxBellPepp
            // 
            this.cbxBellPepp.AutoSize = true;
            this.cbxBellPepp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxBellPepp.Location = new System.Drawing.Point(50, 244);
            this.cbxBellPepp.Name = "cbxBellPepp";
            this.cbxBellPepp.Size = new System.Drawing.Size(83, 17);
            this.cbxBellPepp.TabIndex = 14;
            this.cbxBellPepp.Text = "Bell Peppers";
            this.cbxBellPepp.UseVisualStyleBackColor = true;
            this.cbxBellPepp.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // cbxOnions
            // 
            this.cbxOnions.AutoSize = true;
            this.cbxOnions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxOnions.Location = new System.Drawing.Point(50, 269);
            this.cbxOnions.Name = "cbxOnions";
            this.cbxOnions.Size = new System.Drawing.Size(57, 17);
            this.cbxOnions.TabIndex = 15;
            this.cbxOnions.Text = "Onions";
            this.cbxOnions.UseVisualStyleBackColor = true;
            this.cbxOnions.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // cbxOlives
            // 
            this.cbxOlives.AutoSize = true;
            this.cbxOlives.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbxOlives.Location = new System.Drawing.Point(50, 292);
            this.cbxOlives.Name = "cbxOlives";
            this.cbxOlives.Size = new System.Drawing.Size(53, 17);
            this.cbxOlives.TabIndex = 16;
            this.cbxOlives.Text = "Olives";
            this.cbxOlives.UseVisualStyleBackColor = true;
            this.cbxOlives.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // lblPrice
            // 
            this.lblPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.Location = new System.Drawing.Point(235, 354);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(188, 34);
            this.lblPrice.TabIndex = 17;
            this.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            
            // 
            // rdbTen
            // 
            this.rdbTen.AutoSize = true;
            this.rdbTen.BackColor = System.Drawing.Color.Salmon;
            this.rdbTen.Location = new System.Drawing.Point(185, 41);
            this.rdbTen.Name = "rdbTen";
            this.rdbTen.Size = new System.Drawing.Size(42, 17);
            this.rdbTen.TabIndex = 18;
            this.rdbTen.TabStop = true;
            this.rdbTen.Text = "10\"";
            this.rdbTen.UseVisualStyleBackColor = false;
            this.rdbTen.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // rdbFourteen
            // 
            this.rdbFourteen.AutoSize = true;
            this.rdbFourteen.BackColor = System.Drawing.Color.Salmon;
            this.rdbFourteen.Location = new System.Drawing.Point(291, 41);
            this.rdbFourteen.Name = "rdbFourteen";
            this.rdbFourteen.Size = new System.Drawing.Size(42, 17);
            this.rdbFourteen.TabIndex = 19;
            this.rdbFourteen.TabStop = true;
            this.rdbFourteen.Text = "14\"";
            this.rdbFourteen.UseVisualStyleBackColor = false;
            this.rdbFourteen.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // rdbEightteen
            // 
            this.rdbEightteen.AutoSize = true;
            this.rdbEightteen.BackColor = System.Drawing.Color.Salmon;
            this.rdbEightteen.Location = new System.Drawing.Point(397, 41);
            this.rdbEightteen.Name = "rdbEightteen";
            this.rdbEightteen.Size = new System.Drawing.Size(42, 17);
            this.rdbEightteen.TabIndex = 20;
            this.rdbEightteen.TabStop = true;
            this.rdbEightteen.Text = "18\"";
            this.rdbEightteen.UseVisualStyleBackColor = false;
            this.rdbEightteen.CheckedChanged += new System.EventHandler(this.UpdatePrice);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Salmon;
            this.label5.Location = new System.Drawing.Point(196, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 23);
            this.label5.TabIndex = 21;
            this.label5.Text = "$1.10";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Salmon;
            this.label6.Location = new System.Drawing.Point(196, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 23);
            this.label6.TabIndex = 22;
            this.label6.Text = "$5.25";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Salmon;
            this.label7.Location = new System.Drawing.Point(196, 131);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 23);
            this.label7.TabIndex = 23;
            this.label7.Text = "$1.75";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Salmon;
            this.label8.Location = new System.Drawing.Point(196, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 23);
            this.label8.TabIndex = 24;
            this.label8.Text = "$1.85";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Salmon;
            this.label9.Location = new System.Drawing.Point(196, 177);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 23);
            this.label9.TabIndex = 25;
            this.label9.Text = "$2.00";
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Salmon;
            this.label10.Location = new System.Drawing.Point(196, 200);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 23);
            this.label10.TabIndex = 26;
            this.label10.Text = "$0.95";
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Salmon;
            this.label11.Location = new System.Drawing.Point(196, 223);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 23);
            this.label11.TabIndex = 27;
            this.label11.Text = "$0.65";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Salmon;
            this.label12.Location = new System.Drawing.Point(196, 246);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 23);
            this.label12.TabIndex = 28;
            this.label12.Text = "$0.45";
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Salmon;
            this.label13.Location = new System.Drawing.Point(196, 269);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 23);
            this.label13.TabIndex = 29;
            this.label13.Text = "$0.35";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Salmon;
            this.label14.Location = new System.Drawing.Point(196, 292);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 23);
            this.label14.TabIndex = 30;
            this.label14.Text = "$0.30";
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Salmon;
            this.label15.Location = new System.Drawing.Point(301, 292);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 23);
            this.label15.TabIndex = 39;
            this.label15.Text = "$0.55";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Salmon;
            this.label16.Location = new System.Drawing.Point(301, 269);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 23);
            this.label16.TabIndex = 38;
            this.label16.Text = "$0.65";
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Salmon;
            this.label17.Location = new System.Drawing.Point(301, 246);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 23);
            this.label17.TabIndex = 37;
            this.label17.Text = "$0.85";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Salmon;
            this.label18.Location = new System.Drawing.Point(301, 223);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 23);
            this.label18.TabIndex = 36;
            this.label18.Text = "$1.15";
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Salmon;
            this.label19.Location = new System.Drawing.Point(301, 200);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(56, 23);
            this.label19.TabIndex = 35;
            this.label19.Text = "$1.70";
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Salmon;
            this.label20.Location = new System.Drawing.Point(301, 177);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 23);
            this.label20.TabIndex = 34;
            this.label20.Text = "$3.50";
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Salmon;
            this.label21.Location = new System.Drawing.Point(301, 154);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 23);
            this.label21.TabIndex = 33;
            this.label21.Text = "$3.20";
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Salmon;
            this.label22.Location = new System.Drawing.Point(301, 131);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 23);
            this.label22.TabIndex = 32;
            this.label22.Text = "$3.00";
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Salmon;
            this.label23.Location = new System.Drawing.Point(301, 108);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 23);
            this.label23.TabIndex = 31;
            this.label23.Text = "$2.15";
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.Salmon;
            this.label24.Location = new System.Drawing.Point(410, 292);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(56, 23);
            this.label24.TabIndex = 48;
            this.label24.Text = "$0.90";
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Salmon;
            this.label25.Location = new System.Drawing.Point(410, 269);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 23);
            this.label25.TabIndex = 47;
            this.label25.Text = "$1.00";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Salmon;
            this.label26.Location = new System.Drawing.Point(410, 246);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 23);
            this.label26.TabIndex = 46;
            this.label26.Text = "$1.35";
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Salmon;
            this.label27.Location = new System.Drawing.Point(410, 223);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(56, 23);
            this.label27.TabIndex = 45;
            this.label27.Text = "$1.95";
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.Salmon;
            this.label28.Location = new System.Drawing.Point(410, 200);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(56, 23);
            this.label28.TabIndex = 44;
            this.label28.Text = "$3.15";
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.Salmon;
            this.label29.Location = new System.Drawing.Point(410, 177);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(56, 23);
            this.label29.TabIndex = 43;
            this.label29.Text = "$5.35";
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.Salmon;
            this.label30.Location = new System.Drawing.Point(410, 154);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(56, 23);
            this.label30.TabIndex = 42;
            this.label30.Text = "$4.95";
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.Salmon;
            this.label31.Location = new System.Drawing.Point(410, 131);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(56, 23);
            this.label31.TabIndex = 41;
            this.label31.Text = "$4.85";
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.Salmon;
            this.label32.Location = new System.Drawing.Point(410, 108);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(56, 23);
            this.label32.TabIndex = 40;
            this.label32.Text = "$3.35";
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.Salmon;
            this.label33.Location = new System.Drawing.Point(301, 61);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(56, 23);
            this.label33.TabIndex = 49;
            this.label33.Text = "$9.75";
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.Salmon;
            this.label34.Location = new System.Drawing.Point(410, 61);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(56, 23);
            this.label34.TabIndex = 50;
            this.label34.Text = "$14.50";
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.PeachPuff;
            this.label35.Location = new System.Drawing.Point(24, 58);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(140, 23);
            this.label35.TabIndex = 51;
            this.label35.Text = "Base Price(Cheese Only):";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(669, 397);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.rdbEightteen);
            this.Controls.Add(this.rdbFourteen);
            this.Controls.Add(this.rdbTen);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.cbxOlives);
            this.Controls.Add(this.cbxOnions);
            this.Controls.Add(this.cbxBellPepp);
            this.Controls.Add(this.cbxMushrooms);
            this.Controls.Add(this.cbxPineapple);
            this.Controls.Add(this.cbxCanBacon);
            this.Controls.Add(this.cbxSausage);
            this.Controls.Add(this.cbxPepperoni);
            this.Controls.Add(this.cbxExtraCheese);
            this.Controls.Add(this.btnVeg);
            this.Controls.Add(this.btnHawaiin);
            this.Controls.Add(this.btnPepAndMush);
            this.Controls.Add(this.btnSupreme);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Pizza Parlor Pricer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSupreme;
        private System.Windows.Forms.Button btnPepAndMush;
        private System.Windows.Forms.Button btnHawaiin;
        private System.Windows.Forms.Button btnVeg;
        private System.Windows.Forms.CheckBox cbxExtraCheese;
        private System.Windows.Forms.CheckBox cbxPepperoni;
        private System.Windows.Forms.CheckBox cbxSausage;
        private System.Windows.Forms.CheckBox cbxCanBacon;
        private System.Windows.Forms.CheckBox cbxPineapple;
        private System.Windows.Forms.CheckBox cbxMushrooms;
        private System.Windows.Forms.CheckBox cbxBellPepp;
        private System.Windows.Forms.CheckBox cbxOnions;
        private System.Windows.Forms.CheckBox cbxOlives;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.RadioButton rdbTen;
        private System.Windows.Forms.RadioButton rdbFourteen;
        private System.Windows.Forms.RadioButton rdbEightteen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
    }
}


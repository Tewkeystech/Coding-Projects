﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza_Parlor_Pricer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void UpdatePrice(object sender, EventArgs e)
        {
            double price = 00.0;
            if (rdbTen.Checked)
            {
                price = 5.25;
                if (cbxExtraCheese.Checked)
                {
                    price += 1.10;
                }
                if (cbxPepperoni.Checked)
                {
                    price += 1.75;
                }
                if (cbxSausage.Checked)
                {
                    price += 1.85;
                }
                if (cbxCanBacon.Checked)
                {
                    price += +2.00;
                }
                if (cbxPineapple.Checked)
                {
                    price += +0.95;
                }
                if (cbxMushrooms.Checked)
                {
                    price += 0.65;
                }
                if (cbxBellPepp.Checked)
                {
                    price += 0.45;
                }
                if (cbxOnions.Checked)
                {
                    price += 0.35;
                }
                if (cbxOlives.Checked)
                {
                    price += 0.30;
                }
            }
            else if (rdbFourteen.Checked)
            {
                price = 9.75;
                if (cbxExtraCheese.Checked)
                {
                    price += 2.15;
                }
                if (cbxPepperoni.Checked)
                {
                    price += 3.00;
                }
                if (cbxSausage.Checked)
                {
                    price += 3.20;
                }
                if (cbxCanBacon.Checked)
                {
                    price += +3.50;
                }
                if (cbxPineapple.Checked)
                {
                    price += 1.70;
                }
                if (cbxMushrooms.Checked)
                {
                    price += 1.15;
                }
                if (cbxBellPepp.Checked)
                {
                    price += 0.85;
                }
                if (cbxOnions.Checked)
                {
                    price += 0.65;
                }
                if (cbxOlives.Checked)
                {
                    price += 0.55;
                }
            }
            else if (rdbEightteen.Checked)
            {
                price = 14.50;
                if (cbxExtraCheese.Checked)
                {
                    price += 3.35;
                }
                if (cbxPepperoni.Checked)
                {
                    price += 4.85;
                }
                if (cbxSausage.Checked)
                {
                    price += 4.95;
                }
                if (cbxCanBacon.Checked)
                {
                    price += 5.35;
                }
                if (cbxPineapple.Checked)
                {
                    price += 3.15;
                }
                if (cbxMushrooms.Checked)
                {
                    price += 1.95;
                }
                if (cbxBellPepp.Checked)
                {
                    price += 1.35;
                }
                if (cbxOnions.Checked)
                {
                    price += 1.00;
                }
                if (cbxOlives.Checked)
                {
                    price += 0.90;
                }
            }
            else
            {
                MessageBox.Show("Please select a size", "Size???");
            }
            lblPrice.Text = "PRICE " + price.ToString("C2");

        }


        private void btnSupreme_Click(object sender, EventArgs e)
        {
            cbxExtraCheese.Checked = false;
            cbxPepperoni.Checked = true;
            cbxSausage.Checked = true;
            cbxCanBacon.Checked = false;
            cbxPineapple.Checked = false;
            cbxMushrooms.Checked = true;
            cbxBellPepp.Checked = true;
            cbxOnions.Checked = true;
            cbxOlives.Checked = true;
        }

        private void btnPepAndMush_Click(object sender, EventArgs e)
        {
            cbxExtraCheese.Checked = false;
            cbxPepperoni.Checked = true;
            cbxSausage.Checked = false;
            cbxCanBacon.Checked = false;
            cbxPineapple.Checked = false;
            cbxMushrooms.Checked = true;
            cbxBellPepp.Checked = false;
            cbxOnions.Checked = false;
            cbxOlives.Checked = false;
        }

        private void btnHawaiin_Click(object sender, EventArgs e)
        {
            cbxExtraCheese.Checked = false;
            cbxPepperoni.Checked = false;
            cbxSausage.Checked = false;
            cbxCanBacon.Checked = true;
            cbxPineapple.Checked = true;
            cbxMushrooms.Checked = false;
            cbxBellPepp.Checked = false;
            cbxOnions.Checked = false;
            cbxOlives.Checked = false;
        }

        private void btnVeg_Click(object sender, EventArgs e)
        {
            cbxExtraCheese.Checked = false;
            cbxPepperoni.Checked = false;
            cbxSausage.Checked = false;
            cbxCanBacon.Checked = false;
            cbxPineapple.Checked = false;
            cbxMushrooms.Checked = true;
            cbxBellPepp.Checked = true;
            cbxOnions.Checked = true;
            cbxOlives.Checked = true;
        }

     

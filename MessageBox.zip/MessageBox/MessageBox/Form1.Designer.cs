﻿namespace MessageBox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSimpleOk = new System.Windows.Forms.Button();
            this.btnYesNo = new System.Windows.Forms.Button();
            this.btnQuestionIcon = new System.Windows.Forms.Button();
            this.btnDefault = new System.Windows.Forms.Button();
            this.btnPractice = new System.Windows.Forms.Button();
            this.btnEvenMorePractice = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSimpleOk
            // 
            this.btnSimpleOk.Location = new System.Drawing.Point(157, 32);
            this.btnSimpleOk.Name = "btnSimpleOk";
            this.btnSimpleOk.Size = new System.Drawing.Size(272, 82);
            this.btnSimpleOk.TabIndex = 0;
            this.btnSimpleOk.Text = "Simple Ok MessageBox";
            this.btnSimpleOk.UseVisualStyleBackColor = true;
            this.btnSimpleOk.Click += new System.EventHandler(this.btnSimpleOk_Click);
            // 
            // btnYesNo
            // 
            this.btnYesNo.Location = new System.Drawing.Point(157, 132);
            this.btnYesNo.Name = "btnYesNo";
            this.btnYesNo.Size = new System.Drawing.Size(272, 82);
            this.btnYesNo.TabIndex = 1;
            this.btnYesNo.Text = "With YeseNo Buttons";
            this.btnYesNo.UseVisualStyleBackColor = true;
            // 
            // btnQuestionIcon
            // 
            this.btnQuestionIcon.Location = new System.Drawing.Point(157, 230);
            this.btnQuestionIcon.Name = "btnQuestionIcon";
            this.btnQuestionIcon.Size = new System.Drawing.Size(272, 82);
            this.btnQuestionIcon.TabIndex = 2;
            this.btnQuestionIcon.Text = "With Question Icon";
            this.btnQuestionIcon.UseVisualStyleBackColor = true;
            // 
            // btnDefault
            // 
            this.btnDefault.Location = new System.Drawing.Point(157, 326);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(272, 82);
            this.btnDefault.TabIndex = 3;
            this.btnDefault.Text = "With DefaultChanged";
            this.btnDefault.UseVisualStyleBackColor = true;
            // 
            // btnPractice
            // 
            this.btnPractice.Location = new System.Drawing.Point(157, 435);
            this.btnPractice.Name = "btnPractice";
            this.btnPractice.Size = new System.Drawing.Size(272, 82);
            this.btnPractice.TabIndex = 4;
            this.btnPractice.Text = "More Practice";
            this.btnPractice.UseVisualStyleBackColor = true;
            // 
            // btnEvenMorePractice
            // 
            this.btnEvenMorePractice.Location = new System.Drawing.Point(157, 536);
            this.btnEvenMorePractice.Name = "btnEvenMorePractice";
            this.btnEvenMorePractice.Size = new System.Drawing.Size(272, 82);
            this.btnEvenMorePractice.TabIndex = 5;
            this.btnEvenMorePractice.Text = "Even More Practice";
            this.btnEvenMorePractice.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 663);
            this.Controls.Add(this.btnEvenMorePractice);
            this.Controls.Add(this.btnPractice);
            this.Controls.Add(this.btnDefault);
            this.Controls.Add(this.btnQuestionIcon);
            this.Controls.Add(this.btnYesNo);
            this.Controls.Add(this.btnSimpleOk);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSimpleOk;
        private System.Windows.Forms.Button btnYesNo;
        private System.Windows.Forms.Button btnQuestionIcon;
        private System.Windows.Forms.Button btnDefault;
        private System.Windows.Forms.Button btnPractice;
        private System.Windows.Forms.Button btnEvenMorePractice;
    }
}


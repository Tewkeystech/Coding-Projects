﻿namespace CubeCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtVolume = new System.Windows.Forms.TextBox();
            this.txtSurfaceArea = new System.Windows.Forms.TextBox();
            this.txtCircumference1 = new System.Windows.Forms.TextBox();
            this.txtCircumference2 = new System.Windows.Forms.TextBox();
            this.txtCircumference3 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblLength = new System.Windows.Forms.Label();
            this.lblCircumferenceMagenta = new System.Windows.Forms.Label();
            this.lblCircumferenceBlue = new System.Windows.Forms.Label();
            this.lblCircumferenceOrange = new System.Windows.Forms.Label();
            this.lblTotlaSurfaceArea = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.lblWidth = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(80, 219);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(100, 20);
            this.txtHeight.TabIndex = 0;
            this.txtHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtHeight.TextChanged += new System.EventHandler(this.txtHeight_TextChanged);
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(147, 314);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(100, 20);
            this.txtWidth.TabIndex = 1;
            this.txtWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtWidth.TextChanged += new System.EventHandler(this.txtWidth_TextChanged);
            // 
            // txtLength
            // 
            this.txtLength.Location = new System.Drawing.Point(378, 236);
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(100, 20);
            this.txtLength.TabIndex = 2;
            this.txtLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLength.TextChanged += new System.EventHandler(this.txtLength_TextChanged);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(497, 91);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(186, 78);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtVolume
            // 
            this.txtVolume.Location = new System.Drawing.Point(583, 246);
            this.txtVolume.Name = "txtVolume";
            this.txtVolume.Size = new System.Drawing.Size(100, 20);
            this.txtVolume.TabIndex = 4;
            this.txtVolume.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSurfaceArea
            // 
            this.txtSurfaceArea.Location = new System.Drawing.Point(583, 283);
            this.txtSurfaceArea.Name = "txtSurfaceArea";
            this.txtSurfaceArea.Size = new System.Drawing.Size(100, 20);
            this.txtSurfaceArea.TabIndex = 5;
            this.txtSurfaceArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCircumference1
            // 
            this.txtCircumference1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.txtCircumference1.Location = new System.Drawing.Point(583, 324);
            this.txtCircumference1.Name = "txtCircumference1";
            this.txtCircumference1.Size = new System.Drawing.Size(100, 20);
            this.txtCircumference1.TabIndex = 6;
            this.txtCircumference1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCircumference2
            // 
            this.txtCircumference2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCircumference2.Location = new System.Drawing.Point(583, 359);
            this.txtCircumference2.Name = "txtCircumference2";
            this.txtCircumference2.Size = new System.Drawing.Size(100, 20);
            this.txtCircumference2.TabIndex = 7;
            this.txtCircumference2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCircumference3
            // 
            this.txtCircumference3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.txtCircumference3.Location = new System.Drawing.Point(583, 397);
            this.txtCircumference3.Name = "txtCircumference3";
            this.txtCircumference3.Size = new System.Drawing.Size(100, 20);
            this.txtCircumference3.TabIndex = 8;
            this.txtCircumference3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CubeCalculator.Properties.Resources.A03_Box_Calculator_cube_image;
            this.pictureBox1.Location = new System.Drawing.Point(186, 116);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(186, 192);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // lblHeight
            // 
            this.lblHeight.Location = new System.Drawing.Point(77, 193);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(100, 23);
            this.lblHeight.TabIndex = 10;
            this.lblHeight.Text = "Height";
            // 
            // lblLength
            // 
            this.lblLength.Location = new System.Drawing.Point(378, 210);
            this.lblLength.Name = "lblLength";
            this.lblLength.Size = new System.Drawing.Size(100, 23);
            this.lblLength.TabIndex = 11;
            this.lblLength.Text = "Length";
            // 
            // lblCircumferenceMagenta
            // 
            this.lblCircumferenceMagenta.Location = new System.Drawing.Point(437, 394);
            this.lblCircumferenceMagenta.Name = "lblCircumferenceMagenta";
            this.lblCircumferenceMagenta.Size = new System.Drawing.Size(140, 23);
            this.lblCircumferenceMagenta.TabIndex = 12;
            this.lblCircumferenceMagenta.Text = "Circumference 3 (Magenta):";
            // 
            // lblCircumferenceBlue
            // 
            this.lblCircumferenceBlue.Location = new System.Drawing.Point(449, 359);
            this.lblCircumferenceBlue.Name = "lblCircumferenceBlue";
            this.lblCircumferenceBlue.Size = new System.Drawing.Size(128, 23);
            this.lblCircumferenceBlue.TabIndex = 13;
            this.lblCircumferenceBlue.Text = "Circumference 2 (Blue):";
            // 
            // lblCircumferenceOrange
            // 
            this.lblCircumferenceOrange.Location = new System.Drawing.Point(446, 321);
            this.lblCircumferenceOrange.Name = "lblCircumferenceOrange";
            this.lblCircumferenceOrange.Size = new System.Drawing.Size(131, 23);
            this.lblCircumferenceOrange.TabIndex = 14;
            this.lblCircumferenceOrange.Text = "Circumference 1 (Orange):";
            // 
            // lblTotlaSurfaceArea
            // 
            this.lblTotlaSurfaceArea.Location = new System.Drawing.Point(474, 280);
            this.lblTotlaSurfaceArea.Name = "lblTotlaSurfaceArea";
            this.lblTotlaSurfaceArea.Size = new System.Drawing.Size(103, 23);
            this.lblTotlaSurfaceArea.TabIndex = 15;
            this.lblTotlaSurfaceArea.Text = "Total Surface Area:";
            // 
            // lblVolume
            // 
            this.lblVolume.Location = new System.Drawing.Point(515, 246);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(62, 23);
            this.lblVolume.TabIndex = 16;
            this.lblVolume.Text = "Volume:";
            // 
            // lblWidth
            // 
            this.lblWidth.Location = new System.Drawing.Point(103, 288);
            this.lblWidth.Name = "lblWidth";
            this.lblWidth.Size = new System.Drawing.Size(77, 23);
            this.lblWidth.TabIndex = 17;
            this.lblWidth.Text = "Width";
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(47, 28);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(510, 60);
            this.lblTitle.TabIndex = 18;
            this.lblTitle.Text = "SMCC Visual Cube Calculator";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblWidth);
            this.Controls.Add(this.lblVolume);
            this.Controls.Add(this.lblTotlaSurfaceArea);
            this.Controls.Add(this.lblCircumferenceOrange);
            this.Controls.Add(this.lblCircumferenceBlue);
            this.Controls.Add(this.lblCircumferenceMagenta);
            this.Controls.Add(this.lblLength);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtCircumference3);
            this.Controls.Add(this.txtCircumference2);
            this.Controls.Add(this.txtCircumference1);
            this.Controls.Add(this.txtSurfaceArea);
            this.Controls.Add(this.txtVolume);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtLength);
            this.Controls.Add(this.txtWidth);
            this.Controls.Add(this.txtHeight);
            this.Name = "Form1";
            this.Text = "Cube Calc";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.TextBox txtLength;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtVolume;
        private System.Windows.Forms.TextBox txtSurfaceArea;
        private System.Windows.Forms.TextBox txtCircumference1;
        private System.Windows.Forms.TextBox txtCircumference2;
        private System.Windows.Forms.TextBox txtCircumference3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblLength;
        private System.Windows.Forms.Label lblCircumferenceMagenta;
        private System.Windows.Forms.Label lblCircumferenceBlue;
        private System.Windows.Forms.Label lblCircumferenceOrange;
        private System.Windows.Forms.Label lblTotlaSurfaceArea;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label lblWidth;
        private System.Windows.Forms.Label lblTitle;
    }
}


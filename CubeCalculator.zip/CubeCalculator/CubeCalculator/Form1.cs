﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CubeCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double Height,Width,Length,volume,surface,circum1,circum2,circum3;
            Height = double.Parse(txtHeight.Text);
            Width = double.Parse(txtWidth.Text);
            Length = double.Parse(txtLength.Text);
            volume = Height * Width * Length;
            surface =((Height*Width) +(Height*Length)+(Width*Length))*2;
            circum1 = (Height + Width) * 2;
            circum2 = (Width + Length) * 2;
            circum3 = (Height + Length) * 2;
            txtVolume.Text = volume.ToString("N2");
            txtSurfaceArea.Text = surface.ToString("N2");
            txtCircumference1.Text = circum1.ToString("N2");
            txtCircumference2.Text = circum2.ToString("N2");
            txtCircumference3.Text = circum3.ToString("N2");
        }

        private void txtHeight_TextChanged(object sender, EventArgs e)
        {
            txtVolume.Text = "";
            txtSurfaceArea.Text = "";
            txtCircumference1.Text = "";
            txtCircumference2.Text = "";
            txtCircumference3.Text = "";
             
        }

        private void txtWidth_TextChanged(object sender, EventArgs e)
        {
            txtVolume.Text = "";
            txtSurfaceArea.Text = "";
            txtCircumference1.Text = "";
            txtCircumference2.Text = "";
            txtCircumference3.Text = "";
        }

        private void txtLength_TextChanged(object sender, EventArgs e)
        {
            txtVolume.Text = "";
            txtSurfaceArea.Text = "";
            txtCircumference1.Text = "";
            txtCircumference2.Text = "";
            txtCircumference3.Text = "";
        }
    }
}

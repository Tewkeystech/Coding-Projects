﻿namespace Olympic_Judging
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlGroup = new System.Windows.Forms.GroupBox();
            this.lblOrb1 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lblOrb2 = new System.Windows.Forms.Label();
            this.lblOrb3 = new System.Windows.Forms.Label();
            this.lblOrb4 = new System.Windows.Forms.Label();
            this.lblOrb5 = new System.Windows.Forms.Label();
            this.lblOrb6 = new System.Windows.Forms.Label();
            this.lblOrb7 = new System.Windows.Forms.Label();
            this.lblCountry1 = new System.Windows.Forms.Label();
            this.lblCountry2 = new System.Windows.Forms.Label();
            this.lblCountry3 = new System.Windows.Forms.Label();
            this.lblCountry4 = new System.Windows.Forms.Label();
            this.lblCountry5 = new System.Windows.Forms.Label();
            this.lblCountry6 = new System.Windows.Forms.Label();
            this.lblCountry7 = new System.Windows.Forms.Label();
            this.txtScore1 = new System.Windows.Forms.TextBox();
            this.txtScore2 = new System.Windows.Forms.TextBox();
            this.txtScore3 = new System.Windows.Forms.TextBox();
            this.txtScore4 = new System.Windows.Forms.TextBox();
            this.txtScore5 = new System.Windows.Forms.TextBox();
            this.txtScore6 = new System.Windows.Forms.TextBox();
            this.txtScore7 = new System.Windows.Forms.TextBox();
            this.btnProcess = new System.Windows.Forms.Button();
            this.txtAverageScore = new System.Windows.Forms.TextBox();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.lblHighCountry = new System.Windows.Forms.Label();
            this.lblHighOrb = new System.Windows.Forms.Label();
            this.txtHighScore = new System.Windows.Forms.TextBox();
            this.lblLowOrb = new System.Windows.Forms.Label();
            this.lblLowCountry = new System.Windows.Forms.Label();
            this.txtLowScore = new System.Windows.Forms.TextBox();
            this.lblHigh = new System.Windows.Forms.Label();
            this.lblLow = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.pnlGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Controls.Add(this.lblLow);
            this.panel1.Controls.Add(this.lblHigh);
            this.panel1.Controls.Add(this.txtLowScore);
            this.panel1.Controls.Add(this.lblLowCountry);
            this.panel1.Controls.Add(this.lblLowOrb);
            this.panel1.Controls.Add(this.txtHighScore);
            this.panel1.Controls.Add(this.lblHighOrb);
            this.panel1.Controls.Add(this.lblHighCountry);
            this.panel1.Controls.Add(this.lblInstructions);
            this.panel1.Controls.Add(this.txtAverageScore);
            this.panel1.Location = new System.Drawing.Point(487, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(236, 520);
            this.panel1.TabIndex = 0;
            // 
            // pnlGroup
            // 
            this.pnlGroup.Controls.Add(this.btnProcess);
            this.pnlGroup.Controls.Add(this.txtScore7);
            this.pnlGroup.Controls.Add(this.txtScore6);
            this.pnlGroup.Controls.Add(this.txtScore5);
            this.pnlGroup.Controls.Add(this.txtScore4);
            this.pnlGroup.Controls.Add(this.txtScore3);
            this.pnlGroup.Controls.Add(this.txtScore2);
            this.pnlGroup.Controls.Add(this.txtScore1);
            this.pnlGroup.Controls.Add(this.lblCountry7);
            this.pnlGroup.Controls.Add(this.lblCountry6);
            this.pnlGroup.Controls.Add(this.lblCountry5);
            this.pnlGroup.Controls.Add(this.lblCountry4);
            this.pnlGroup.Controls.Add(this.lblCountry3);
            this.pnlGroup.Controls.Add(this.lblCountry2);
            this.pnlGroup.Controls.Add(this.lblCountry1);
            this.pnlGroup.Controls.Add(this.lblOrb7);
            this.pnlGroup.Controls.Add(this.lblOrb6);
            this.pnlGroup.Controls.Add(this.lblOrb5);
            this.pnlGroup.Controls.Add(this.lblOrb4);
            this.pnlGroup.Controls.Add(this.lblOrb3);
            this.pnlGroup.Controls.Add(this.lblOrb2);
            this.pnlGroup.Controls.Add(this.lblOrb1);
            this.pnlGroup.Location = new System.Drawing.Point(12, 12);
            this.pnlGroup.Name = "pnlGroup";
            this.pnlGroup.Size = new System.Drawing.Size(449, 498);
            this.pnlGroup.TabIndex = 1;
            this.pnlGroup.TabStop = false;
            this.pnlGroup.Text = "Enter individual scores";
            this.pnlGroup.Enter += new System.EventHandler(this.Enter_Enter);
            // 
            // lblOrb1
            // 
            this.lblOrb1.ImageIndex = 0;
            this.lblOrb1.ImageList = this.imageList1;
            this.lblOrb1.Location = new System.Drawing.Point(15, 61);
            this.lblOrb1.Margin = new System.Windows.Forms.Padding(150);
            this.lblOrb1.Name = "lblOrb1";
            this.lblOrb1.Size = new System.Drawing.Size(83, 73);
            this.lblOrb1.TabIndex = 0;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "china.png");
            this.imageList1.Images.SetKeyName(1, "france.png");
            this.imageList1.Images.SetKeyName(2, "germany.png");
            this.imageList1.Images.SetKeyName(3, "great_britain.png");
            this.imageList1.Images.SetKeyName(4, "sweden.png");
            this.imageList1.Images.SetKeyName(5, "united_states.png");
            this.imageList1.Images.SetKeyName(6, "zimbabwe.png");
            // 
            // lblOrb2
            // 
            this.lblOrb2.ImageIndex = 1;
            this.lblOrb2.ImageList = this.imageList1;
            this.lblOrb2.Location = new System.Drawing.Point(15, 166);
            this.lblOrb2.Margin = new System.Windows.Forms.Padding(150);
            this.lblOrb2.Name = "lblOrb2";
            this.lblOrb2.Size = new System.Drawing.Size(83, 73);
            this.lblOrb2.TabIndex = 1;
            // 
            // lblOrb3
            // 
            this.lblOrb3.ImageIndex = 2;
            this.lblOrb3.ImageList = this.imageList1;
            this.lblOrb3.Location = new System.Drawing.Point(15, 278);
            this.lblOrb3.Margin = new System.Windows.Forms.Padding(150);
            this.lblOrb3.Name = "lblOrb3";
            this.lblOrb3.Size = new System.Drawing.Size(83, 73);
            this.lblOrb3.TabIndex = 2;
            // 
            // lblOrb4
            // 
            this.lblOrb4.ImageIndex = 3;
            this.lblOrb4.ImageList = this.imageList1;
            this.lblOrb4.Location = new System.Drawing.Point(15, 386);
            this.lblOrb4.Margin = new System.Windows.Forms.Padding(150);
            this.lblOrb4.Name = "lblOrb4";
            this.lblOrb4.Size = new System.Drawing.Size(83, 73);
            this.lblOrb4.TabIndex = 3;
            // 
            // lblOrb5
            // 
            this.lblOrb5.ImageIndex = 4;
            this.lblOrb5.ImageList = this.imageList1;
            this.lblOrb5.Location = new System.Drawing.Point(239, 61);
            this.lblOrb5.Margin = new System.Windows.Forms.Padding(150);
            this.lblOrb5.Name = "lblOrb5";
            this.lblOrb5.Size = new System.Drawing.Size(83, 73);
            this.lblOrb5.TabIndex = 4;
            // 
            // lblOrb6
            // 
            this.lblOrb6.ImageIndex = 5;
            this.lblOrb6.ImageList = this.imageList1;
            this.lblOrb6.Location = new System.Drawing.Point(239, 166);
            this.lblOrb6.Margin = new System.Windows.Forms.Padding(150);
            this.lblOrb6.Name = "lblOrb6";
            this.lblOrb6.Size = new System.Drawing.Size(83, 73);
            this.lblOrb6.TabIndex = 5;
            // 
            // lblOrb7
            // 
            this.lblOrb7.ImageIndex = 6;
            this.lblOrb7.ImageList = this.imageList1;
            this.lblOrb7.Location = new System.Drawing.Point(239, 278);
            this.lblOrb7.Margin = new System.Windows.Forms.Padding(150);
            this.lblOrb7.Name = "lblOrb7";
            this.lblOrb7.Size = new System.Drawing.Size(83, 73);
            this.lblOrb7.TabIndex = 6;
            // 
            // lblCountry1
            // 
            this.lblCountry1.AutoSize = true;
            this.lblCountry1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry1.Location = new System.Drawing.Point(120, 61);
            this.lblCountry1.Name = "lblCountry1";
            this.lblCountry1.Size = new System.Drawing.Size(46, 16);
            this.lblCountry1.TabIndex = 7;
            this.lblCountry1.Text = "China";
            // 
            // lblCountry2
            // 
            this.lblCountry2.AutoSize = true;
            this.lblCountry2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry2.Location = new System.Drawing.Point(120, 166);
            this.lblCountry2.Name = "lblCountry2";
            this.lblCountry2.Size = new System.Drawing.Size(55, 16);
            this.lblCountry2.TabIndex = 8;
            this.lblCountry2.Text = "France";
            // 
            // lblCountry3
            // 
            this.lblCountry3.AutoSize = true;
            this.lblCountry3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry3.Location = new System.Drawing.Point(111, 278);
            this.lblCountry3.Name = "lblCountry3";
            this.lblCountry3.Size = new System.Drawing.Size(69, 16);
            this.lblCountry3.TabIndex = 9;
            this.lblCountry3.Text = "Germany";
            // 
            // lblCountry4
            // 
            this.lblCountry4.AutoSize = true;
            this.lblCountry4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry4.Location = new System.Drawing.Point(111, 386);
            this.lblCountry4.Name = "lblCountry4";
            this.lblCountry4.Size = new System.Drawing.Size(93, 16);
            this.lblCountry4.TabIndex = 10;
            this.lblCountry4.Text = "Great Britain";
            // 
            // lblCountry5
            // 
            this.lblCountry5.AutoSize = true;
            this.lblCountry5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry5.Location = new System.Drawing.Point(338, 61);
            this.lblCountry5.Name = "lblCountry5";
            this.lblCountry5.Size = new System.Drawing.Size(62, 16);
            this.lblCountry5.TabIndex = 11;
            this.lblCountry5.Text = "Sweden";
            // 
            // lblCountry6
            // 
            this.lblCountry6.AutoSize = true;
            this.lblCountry6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry6.Location = new System.Drawing.Point(338, 166);
            this.lblCountry6.Name = "lblCountry6";
            this.lblCountry6.Size = new System.Drawing.Size(100, 16);
            this.lblCountry6.TabIndex = 12;
            this.lblCountry6.Text = "United States";
            // 
            // lblCountry7
            // 
            this.lblCountry7.AutoSize = true;
            this.lblCountry7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry7.Location = new System.Drawing.Point(338, 278);
            this.lblCountry7.Name = "lblCountry7";
            this.lblCountry7.Size = new System.Drawing.Size(78, 16);
            this.lblCountry7.TabIndex = 13;
            this.lblCountry7.Text = "Zimbabwe";
            // 
            // txtScore1
            // 
            this.txtScore1.BackColor = System.Drawing.Color.Yellow;
            this.txtScore1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtScore1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore1.Location = new System.Drawing.Point(114, 80);
            this.txtScore1.Multiline = true;
            this.txtScore1.Name = "txtScore1";
            this.txtScore1.Size = new System.Drawing.Size(86, 33);
            this.txtScore1.TabIndex = 14;
            this.txtScore1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtScore2
            // 
            this.txtScore2.BackColor = System.Drawing.Color.Yellow;
            this.txtScore2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtScore2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore2.Location = new System.Drawing.Point(114, 185);
            this.txtScore2.Multiline = true;
            this.txtScore2.Name = "txtScore2";
            this.txtScore2.Size = new System.Drawing.Size(86, 33);
            this.txtScore2.TabIndex = 15;
            this.txtScore2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtScore3
            // 
            this.txtScore3.BackColor = System.Drawing.Color.Yellow;
            this.txtScore3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtScore3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore3.Location = new System.Drawing.Point(114, 297);
            this.txtScore3.Multiline = true;
            this.txtScore3.Name = "txtScore3";
            this.txtScore3.Size = new System.Drawing.Size(86, 33);
            this.txtScore3.TabIndex = 16;
            this.txtScore3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtScore4
            // 
            this.txtScore4.BackColor = System.Drawing.Color.Yellow;
            this.txtScore4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtScore4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore4.Location = new System.Drawing.Point(123, 405);
            this.txtScore4.Multiline = true;
            this.txtScore4.Name = "txtScore4";
            this.txtScore4.Size = new System.Drawing.Size(86, 33);
            this.txtScore4.TabIndex = 17;
            this.txtScore4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtScore5
            // 
            this.txtScore5.BackColor = System.Drawing.Color.Yellow;
            this.txtScore5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtScore5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore5.Location = new System.Drawing.Point(341, 80);
            this.txtScore5.Multiline = true;
            this.txtScore5.Name = "txtScore5";
            this.txtScore5.Size = new System.Drawing.Size(86, 33);
            this.txtScore5.TabIndex = 18;
            this.txtScore5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtScore6
            // 
            this.txtScore6.BackColor = System.Drawing.Color.Yellow;
            this.txtScore6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtScore6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore6.Location = new System.Drawing.Point(341, 185);
            this.txtScore6.Multiline = true;
            this.txtScore6.Name = "txtScore6";
            this.txtScore6.Size = new System.Drawing.Size(86, 33);
            this.txtScore6.TabIndex = 19;
            this.txtScore6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtScore7
            // 
            this.txtScore7.BackColor = System.Drawing.Color.Yellow;
            this.txtScore7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtScore7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore7.Location = new System.Drawing.Point(341, 297);
            this.txtScore7.Multiline = true;
            this.txtScore7.Name = "txtScore7";
            this.txtScore7.Size = new System.Drawing.Size(86, 33);
            this.txtScore7.TabIndex = 20;
            this.txtScore7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnProcess
            // 
            this.btnProcess.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnProcess.Location = new System.Drawing.Point(280, 386);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(120, 46);
            this.btnProcess.TabIndex = 21;
            this.btnProcess.Text = "Process the scores";
            this.btnProcess.UseVisualStyleBackColor = false;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // txtAverageScore
            // 
            this.txtAverageScore.BackColor = System.Drawing.Color.Lime;
            this.txtAverageScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAverageScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAverageScore.Location = new System.Drawing.Point(45, 74);
            this.txtAverageScore.Multiline = true;
            this.txtAverageScore.Name = "txtAverageScore";
            this.txtAverageScore.Size = new System.Drawing.Size(170, 52);
            this.txtAverageScore.TabIndex = 0;
            this.txtAverageScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblInstructions
            // 
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructions.Location = new System.Drawing.Point(41, 57);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(173, 13);
            this.lblInstructions.TabIndex = 1;
            this.lblInstructions.Text = "Average score of middle five:";
            // 
            // lblHighCountry
            // 
            this.lblHighCountry.AutoSize = true;
            this.lblHighCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHighCountry.Location = new System.Drawing.Point(120, 249);
            this.lblHighCountry.Name = "lblHighCountry";
            this.lblHighCountry.Size = new System.Drawing.Size(0, 18);
            this.lblHighCountry.TabIndex = 2;
            // 
            // lblHighOrb
            // 
            this.lblHighOrb.ImageIndex = 0;
            this.lblHighOrb.ImageList = this.imageList1;
            this.lblHighOrb.Location = new System.Drawing.Point(42, 240);
            this.lblHighOrb.Name = "lblHighOrb";
            this.lblHighOrb.Size = new System.Drawing.Size(66, 66);
            this.lblHighOrb.TabIndex = 3;
            // 
            // txtHighScore
            // 
            this.txtHighScore.BackColor = System.Drawing.Color.Red;
            this.txtHighScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHighScore.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtHighScore.Location = new System.Drawing.Point(123, 265);
            this.txtHighScore.Multiline = true;
            this.txtHighScore.Name = "txtHighScore";
            this.txtHighScore.Size = new System.Drawing.Size(57, 29);
            this.txtHighScore.TabIndex = 4;
            this.txtHighScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblLowOrb
            // 
            this.lblLowOrb.ImageIndex = 0;
            this.lblLowOrb.ImageList = this.imageList1;
            this.lblLowOrb.Location = new System.Drawing.Point(42, 388);
            this.lblLowOrb.Name = "lblLowOrb";
            this.lblLowOrb.Size = new System.Drawing.Size(66, 66);
            this.lblLowOrb.TabIndex = 5;
            this.lblLowOrb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLowCountry
            // 
            this.lblLowCountry.AutoSize = true;
            this.lblLowCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLowCountry.Location = new System.Drawing.Point(123, 398);
            this.lblLowCountry.Name = "lblLowCountry";
            this.lblLowCountry.Size = new System.Drawing.Size(0, 18);
            this.lblLowCountry.TabIndex = 6;
            // 
            // txtLowScore
            // 
            this.txtLowScore.BackColor = System.Drawing.Color.Red;
            this.txtLowScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLowScore.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtLowScore.Location = new System.Drawing.Point(126, 415);
            this.txtLowScore.Multiline = true;
            this.txtLowScore.Name = "txtLowScore";
            this.txtLowScore.Size = new System.Drawing.Size(57, 29);
            this.txtLowScore.TabIndex = 7;
            this.txtLowScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblHigh
            // 
            this.lblHigh.AutoSize = true;
            this.lblHigh.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHigh.Location = new System.Drawing.Point(26, 204);
            this.lblHigh.Name = "lblHigh";
            this.lblHigh.Size = new System.Drawing.Size(143, 29);
            this.lblHigh.TabIndex = 8;
            this.lblHigh.Text = "High Score";
            // 
            // lblLow
            // 
            this.lblLow.AutoSize = true;
            this.lblLow.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLow.Location = new System.Drawing.Point(26, 348);
            this.lblLow.Name = "lblLow";
            this.lblLow.Size = new System.Drawing.Size(137, 29);
            this.lblLow.TabIndex = 9;
            this.lblLow.Text = "Low Score";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 522);
            this.Controls.Add(this.pnlGroup);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Olymic Judging";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlGroup.ResumeLayout(false);
            this.pnlGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox pnlGroup;
        private System.Windows.Forms.Label lblOrb1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label lblOrb5;
        private System.Windows.Forms.Label lblOrb4;
        private System.Windows.Forms.Label lblOrb3;
        private System.Windows.Forms.Label lblOrb2;
        private System.Windows.Forms.Label lblCountry7;
        private System.Windows.Forms.Label lblCountry6;
        private System.Windows.Forms.Label lblCountry5;
        private System.Windows.Forms.Label lblCountry4;
        private System.Windows.Forms.Label lblCountry3;
        private System.Windows.Forms.Label lblCountry2;
        private System.Windows.Forms.Label lblCountry1;
        private System.Windows.Forms.Label lblOrb7;
        private System.Windows.Forms.Label lblOrb6;
        private System.Windows.Forms.TextBox txtScore1;
        private System.Windows.Forms.TextBox txtScore7;
        private System.Windows.Forms.TextBox txtScore6;
        private System.Windows.Forms.TextBox txtScore5;
        private System.Windows.Forms.TextBox txtScore4;
        private System.Windows.Forms.TextBox txtScore3;
        private System.Windows.Forms.TextBox txtScore2;
        private System.Windows.Forms.TextBox txtAverageScore;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.TextBox txtHighScore;
        private System.Windows.Forms.Label lblHighOrb;
        private System.Windows.Forms.Label lblHighCountry;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.TextBox txtLowScore;
        private System.Windows.Forms.Label lblLowCountry;
        private System.Windows.Forms.Label lblLowOrb;
        private System.Windows.Forms.Label lblHigh;
        private System.Windows.Forms.Label lblLow;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Olympic_Judging
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Enter_Enter(object sender, EventArgs e)
        {

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            double total;
            double avgScore;

            total = double.Parse(txtScore1.Text) + double.Parse(txtScore2.Text) + double.Parse(txtScore3.Text) +
                double.Parse(txtScore4.Text) + double.Parse(txtScore5.Text) + double.Parse(txtScore6.Text) + double.Parse(txtScore7.Text);

            txtHighScore.Text = txtScore1.Text;
            lblHighOrb.ImageIndex = lblOrb1.ImageIndex;
            lblHighCountry.Text = lblCountry1.Text;
            if (double.Parse(txtScore2.Text) > double.Parse(txtHighScore.Text))
            {
                txtHighScore.Text = txtScore2.Text;
                lblHighOrb.ImageIndex = lblOrb2.ImageIndex;
                lblHighCountry.Text = lblCountry2.Text;
            }
            if (double.Parse(txtScore3.Text) > double.Parse(txtHighScore.Text))
            {
                txtHighScore.Text = txtScore3.Text;
                lblHighOrb.ImageIndex = lblOrb3.ImageIndex;
                lblHighCountry.Text = lblCountry3.Text;
            }
            if (double.Parse(txtScore4.Text) > double.Parse(txtHighScore.Text))
            {
                txtHighScore.Text = txtHighScore.Text;
                lblHighOrb.ImageIndex = lblOrb4.ImageIndex;
                lblHighCountry.Text = lblCountry4.Text;
            }
            if (double.Parse(txtScore5.Text) > double.Parse(txtHighScore.Text))
            {
                txtHighScore.Text = txtHighScore.Text;
                lblHighOrb.ImageIndex = lblOrb5.ImageIndex;
                lblHighCountry.Text = lblCountry5.Text;
            }
            if (double.Parse(txtScore6.Text) > double.Parse(txtHighScore.Text))
            {
                txtHighScore.Text = txtHighScore.Text;
                lblHighOrb.ImageIndex = lblOrb6.ImageIndex;
                lblHighCountry.Text = lblCountry6.Text;
            }
            if (double.Parse(txtScore7.Text) > double.Parse(txtHighScore.Text))
            {
                txtHighScore.Text = txtHighScore.Text;
                lblHighOrb.ImageIndex = lblOrb7.ImageIndex;
                lblHighCountry.Text = lblCountry7.Text;
            }

            txtLowScore.Text = txtScore1.Text;
            lblLowOrb.ImageIndex = lblOrb1.ImageIndex;
            lblLowCountry.Text = lblCountry1.Text;
            if (double.Parse(txtScore2.Text) < double.Parse(txtLowScore.Text))
            {
                txtLowScore.Text = txtScore2.Text;
                lblLowOrb.ImageIndex = lblOrb2.ImageIndex;
                lblLowCountry.Text = lblCountry2.Text;
            }
            if (double.Parse(txtScore3.Text) < double.Parse(txtLowScore.Text))
            {
                txtLowScore.Text = txtScore3.Text;
                lblLowOrb.ImageIndex = lblOrb3.ImageIndex;
                lblLowCountry.Text = lblCountry3.Text;
            }
            if (double.Parse(txtScore4.Text) < double.Parse(txtLowScore.Text))
            {
                txtLowScore.Text = txtLowScore.Text;
                lblLowOrb.ImageIndex = lblOrb4.ImageIndex;
                lblLowCountry.Text = lblCountry4.Text;
            }
            if (double.Parse(txtScore5.Text) < double.Parse(txtLowScore.Text))
            {
                txtLowScore.Text = txtLowScore.Text;
                lblLowOrb.ImageIndex = lblOrb5.ImageIndex;
                lblLowCountry.Text = lblCountry5.Text;
            }
            if (double.Parse(txtScore6.Text) < double.Parse(txtLowScore.Text))
            {
                txtLowScore.Text = txtLowScore.Text;
                lblLowOrb.ImageIndex = lblOrb6.ImageIndex;
                lblLowCountry.Text = lblCountry6.Text;
            }
            if (double.Parse(txtScore7.Text) < double.Parse(txtLowScore.Text))
            {
                txtLowScore.Text = txtLowScore.Text;
                lblLowOrb.ImageIndex = lblOrb7.ImageIndex;
                lblLowCountry.Text = lblCountry7.Text;
            }
            total -= double.Parse(txtHighScore.Text);
            total -= double.Parse(txtLowScore.Text);
            avgScore = total / 5.0;

            txtAverageScore.Text = avgScore.ToString("n2");
        }
    }
}

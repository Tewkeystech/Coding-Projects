﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0002_College_Colors
{
    public partial class CollegeColors : Form
    {
        public CollegeColors()
        {
            InitializeComponent();
        }

        private void lblCampus_Click(object sender, EventArgs e)
        {

        }

        private void btnSMCC_Click(object sender, EventArgs e)
        {
            lblCampus.Text = "South Mountain Community College";
            lblCampus.BackColor = Color.FromArgb(207, 127, 0);
            lblCampus.ForeColor = Color.White;
            lblLogo.ImageIndex = 0;
        }

        private void btnASU_Click(object sender, EventArgs e)
        {
            lblCampus.Text = "Arizona State University";
            lblCampus.BackColor = Color.FromArgb(140,29,64);
            lblCampus.ForeColor = Color.FromArgb(255,198,39);
            lblLogo.ImageIndex = 1;
        }

        private void btnUofA_Click(object sender, EventArgs e)
        {
            lblCampus.Text = "University of Arizona";
            lblCampus.BackColor = Color.Navy;
            lblCampus.ForeColor = Color.Red;
            lblLogo.ImageIndex = 2;
        }

        private void btnNAU_Click(object sender, EventArgs e)
        {
            lblCampus.Text = "Northern Arizona University";
            lblCampus.BackColor = Color.DarkBlue;
            lblCampus.ForeColor = Color.Gold;
            lblLogo.ImageIndex = 3;
        }

        private void btnGCU_Click(object sender, EventArgs e)
        {
            lblCampus.Text = "Grand Canyon University";
            lblCampus.BackColor = Color.Purple;
            lblCampus.ForeColor = Color.White;
            lblLogo.ImageIndex = 4;
        }
    }
}

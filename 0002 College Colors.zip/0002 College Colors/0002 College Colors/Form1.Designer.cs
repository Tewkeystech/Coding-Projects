﻿namespace _0002_College_Colors
{
    partial class CollegeColors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CollegeColors));
            this.lblCampus = new System.Windows.Forms.Label();
            this.btnSMCC = new System.Windows.Forms.Button();
            this.btnASU = new System.Windows.Forms.Button();
            this.btnUofA = new System.Windows.Forms.Button();
            this.btnNAU = new System.Windows.Forms.Button();
            this.btnGCU = new System.Windows.Forms.Button();
            this.lblLogo = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imgLogos = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // lblCampus
            // 
            this.lblCampus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCampus.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCampus.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblCampus.Location = new System.Drawing.Point(77, 272);
            this.lblCampus.Name = "lblCampus";
            this.lblCampus.Size = new System.Drawing.Size(555, 71);
            this.lblCampus.TabIndex = 0;
            this.lblCampus.Text = "Click a campus button below:";
            this.lblCampus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCampus.Click += new System.EventHandler(this.lblCampus_Click);
            // 
            // btnSMCC
            // 
            this.btnSMCC.Location = new System.Drawing.Point(78, 386);
            this.btnSMCC.Name = "btnSMCC";
            this.btnSMCC.Size = new System.Drawing.Size(75, 23);
            this.btnSMCC.TabIndex = 1;
            this.btnSMCC.Text = "SMCC";
            this.btnSMCC.UseVisualStyleBackColor = true;
            this.btnSMCC.Click += new System.EventHandler(this.btnSMCC_Click);
            // 
            // btnASU
            // 
            this.btnASU.Location = new System.Drawing.Point(193, 386);
            this.btnASU.Name = "btnASU";
            this.btnASU.Size = new System.Drawing.Size(75, 23);
            this.btnASU.TabIndex = 2;
            this.btnASU.Text = "ASU";
            this.btnASU.UseVisualStyleBackColor = true;
            this.btnASU.Click += new System.EventHandler(this.btnASU_Click);
            // 
            // btnUofA
            // 
            this.btnUofA.Location = new System.Drawing.Point(311, 386);
            this.btnUofA.Name = "btnUofA";
            this.btnUofA.Size = new System.Drawing.Size(75, 23);
            this.btnUofA.TabIndex = 3;
            this.btnUofA.Text = "U of A";
            this.btnUofA.UseVisualStyleBackColor = true;
            this.btnUofA.Click += new System.EventHandler(this.btnUofA_Click);
            // 
            // btnNAU
            // 
            this.btnNAU.Location = new System.Drawing.Point(427, 386);
            this.btnNAU.Name = "btnNAU";
            this.btnNAU.Size = new System.Drawing.Size(75, 23);
            this.btnNAU.TabIndex = 4;
            this.btnNAU.Text = "NAU";
            this.btnNAU.UseVisualStyleBackColor = true;
            this.btnNAU.Click += new System.EventHandler(this.btnNAU_Click);
            // 
            // btnGCU
            // 
            this.btnGCU.Location = new System.Drawing.Point(558, 386);
            this.btnGCU.Name = "btnGCU";
            this.btnGCU.Size = new System.Drawing.Size(75, 23);
            this.btnGCU.TabIndex = 5;
            this.btnGCU.Text = "GCU";
            this.btnGCU.UseVisualStyleBackColor = true;
            this.btnGCU.Click += new System.EventHandler(this.btnGCU_Click);
            // 
            // lblLogo
            // 
            this.lblLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLogo.ImageIndex = 0;
            this.lblLogo.ImageList = this.imgLogos;
            this.lblLogo.Location = new System.Drawing.Point(220, 102);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(255, 125);
            this.lblLogo.TabIndex = 6;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imgLogos
            // 
            this.imgLogos.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgLogos.ImageStream")));
            this.imgLogos.TransparentColor = System.Drawing.Color.Transparent;
            this.imgLogos.Images.SetKeyName(0, "SMCC.jpg");
            this.imgLogos.Images.SetKeyName(1, "ASU.jpg");
            this.imgLogos.Images.SetKeyName(2, "UA.jpg");
            this.imgLogos.Images.SetKeyName(3, "NAU.jpg");
            this.imgLogos.Images.SetKeyName(4, "GCU.jpg");
            // 
            // CollegeColors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 538);
            this.Controls.Add(this.lblLogo);
            this.Controls.Add(this.btnGCU);
            this.Controls.Add(this.btnNAU);
            this.Controls.Add(this.btnUofA);
            this.Controls.Add(this.btnASU);
            this.Controls.Add(this.btnSMCC);
            this.Controls.Add(this.lblCampus);
            this.Name = "CollegeColors";
            this.Text = "c";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblCampus;
        private System.Windows.Forms.Button btnSMCC;
        private System.Windows.Forms.Button btnASU;
        private System.Windows.Forms.Button btnUofA;
        private System.Windows.Forms.Button btnNAU;
        private System.Windows.Forms.Button btnGCU;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imgLogos;
    }
}


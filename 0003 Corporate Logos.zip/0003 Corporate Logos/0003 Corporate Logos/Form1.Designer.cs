﻿namespace _0003_Corporate_Logos
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnAdobe = new System.Windows.Forms.Button();
            this.btnASUS = new System.Windows.Forms.Button();
            this.btnDell = new System.Windows.Forms.Button();
            this.btnHP = new System.Windows.Forms.Button();
            this.btnMicrosoft = new System.Windows.Forms.Button();
            this.btnSMCC = new System.Windows.Forms.Button();
            this.lblLogo = new System.Windows.Forms.Label();
            this.lblCorpName = new System.Windows.Forms.Label();
            this.lblCorpLocation = new System.Windows.Forms.Label();
            this.imgLogos = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // btnAdobe
            // 
            this.btnAdobe.BackColor = System.Drawing.Color.Transparent;
            this.btnAdobe.Location = new System.Drawing.Point(21, 6);
            this.btnAdobe.Name = "btnAdobe";
            this.btnAdobe.Size = new System.Drawing.Size(108, 52);
            this.btnAdobe.TabIndex = 0;
            this.btnAdobe.Text = "Adobe";
            this.btnAdobe.UseVisualStyleBackColor = false;
            this.btnAdobe.Click += new System.EventHandler(this.btnAdobe_Click);
            // 
            // btnASUS
            // 
            this.btnASUS.Location = new System.Drawing.Point(21, 65);
            this.btnASUS.Name = "btnASUS";
            this.btnASUS.Size = new System.Drawing.Size(108, 52);
            this.btnASUS.TabIndex = 1;
            this.btnASUS.Text = "ASUS";
            this.btnASUS.UseVisualStyleBackColor = true;
            this.btnASUS.Click += new System.EventHandler(this.btnASUS_Click);
            // 
            // btnDell
            // 
            this.btnDell.Location = new System.Drawing.Point(21, 124);
            this.btnDell.Name = "btnDell";
            this.btnDell.Size = new System.Drawing.Size(108, 52);
            this.btnDell.TabIndex = 2;
            this.btnDell.Text = "Dell";
            this.btnDell.UseVisualStyleBackColor = true;
            this.btnDell.Click += new System.EventHandler(this.btnDell_Click);
            // 
            // btnHP
            // 
            this.btnHP.Location = new System.Drawing.Point(21, 183);
            this.btnHP.Name = "btnHP";
            this.btnHP.Size = new System.Drawing.Size(108, 52);
            this.btnHP.TabIndex = 3;
            this.btnHP.Text = "Hewlett Packard";
            this.btnHP.UseVisualStyleBackColor = true;
            this.btnHP.Click += new System.EventHandler(this.btnHP_Click);
            // 
            // btnMicrosoft
            // 
            this.btnMicrosoft.Location = new System.Drawing.Point(21, 242);
            this.btnMicrosoft.Name = "btnMicrosoft";
            this.btnMicrosoft.Size = new System.Drawing.Size(108, 52);
            this.btnMicrosoft.TabIndex = 4;
            this.btnMicrosoft.Text = "Microsoft";
            this.btnMicrosoft.UseVisualStyleBackColor = true;
            this.btnMicrosoft.Click += new System.EventHandler(this.btnMicrosoft_Click);
            // 
            // btnSMCC
            // 
            this.btnSMCC.Location = new System.Drawing.Point(21, 301);
            this.btnSMCC.Name = "btnSMCC";
            this.btnSMCC.Size = new System.Drawing.Size(108, 52);
            this.btnSMCC.TabIndex = 5;
            this.btnSMCC.Text = "South Mountain Community College";
            this.btnSMCC.UseVisualStyleBackColor = true;
            this.btnSMCC.Click += new System.EventHandler(this.btnSMCC_Click);
            // 
            // lblLogo
            // 
            this.lblLogo.BackColor = System.Drawing.Color.Black;
            this.lblLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLogo.ImageList = this.imgLogos;
            this.lblLogo.Location = new System.Drawing.Point(176, 33);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(250, 250);
            this.lblLogo.TabIndex = 6;
            // 
            // lblCorpName
            // 
            this.lblCorpName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorpName.Location = new System.Drawing.Point(164, 290);
            this.lblCorpName.Name = "lblCorpName";
            this.lblCorpName.Size = new System.Drawing.Size(308, 38);
            this.lblCorpName.TabIndex = 7;
            this.lblCorpName.Text = "Click a button to the left:";
            this.lblCorpName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCorpLocation
            // 
            this.lblCorpLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorpLocation.Location = new System.Drawing.Point(173, 326);
            this.lblCorpLocation.Name = "lblCorpLocation";
            this.lblCorpLocation.Size = new System.Drawing.Size(276, 26);
            this.lblCorpLocation.TabIndex = 8;
            this.lblCorpLocation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // imgLogos
            // 
            this.imgLogos.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgLogos.ImageStream")));
            this.imgLogos.TransparentColor = System.Drawing.Color.Transparent;
            this.imgLogos.Images.SetKeyName(0, "logo_adobe.jpg");
            this.imgLogos.Images.SetKeyName(1, "logo_asus.jpg");
            this.imgLogos.Images.SetKeyName(2, "logo_dell.jpg");
            this.imgLogos.Images.SetKeyName(3, "logo_hp.jpg");
            this.imgLogos.Images.SetKeyName(4, "logo_microsoft.jpg");
            this.imgLogos.Images.SetKeyName(5, "logo_smcc.jpg");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 361);
            this.Controls.Add(this.lblCorpLocation);
            this.Controls.Add(this.lblCorpName);
            this.Controls.Add(this.lblLogo);
            this.Controls.Add(this.btnSMCC);
            this.Controls.Add(this.btnMicrosoft);
            this.Controls.Add(this.btnHP);
            this.Controls.Add(this.btnDell);
            this.Controls.Add(this.btnASUS);
            this.Controls.Add(this.btnAdobe);
            this.Name = "Form1";
            this.Text = "Corporate Logo (C#)";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAdobe;
        private System.Windows.Forms.Button btnASUS;
        private System.Windows.Forms.Button btnDell;
        private System.Windows.Forms.Button btnHP;
        private System.Windows.Forms.Button btnMicrosoft;
        private System.Windows.Forms.Button btnSMCC;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Label lblCorpName;
        private System.Windows.Forms.Label lblCorpLocation;
        private System.Windows.Forms.ImageList imgLogos;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0003_Corporate_Logos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdobe_Click(object sender, EventArgs e)
        {
            lblLogo.ImageIndex = 0;
            lblCorpName.Text = "Adobe Systems";
            lblCorpLocation.Text = "San Jose, CA";
        }

        private void btnASUS_Click(object sender, EventArgs e)
        {
            lblLogo.ImageIndex = 1;
            lblCorpName.Text = "ASUS";
            lblCorpLocation.Text = "Beitou District, Taipei, Taiwan";
        }

        private void btnDell_Click(object sender, EventArgs e)
        {
            lblLogo.ImageIndex = 2;
            lblCorpName.Text = "Dell Computer";
            lblCorpLocation.Text = "Austin, TX";
        }

        private void btnHP_Click(object sender, EventArgs e)
        {
            lblLogo.ImageIndex = 3;
            lblCorpName.Text = "Hewlett-Packard";
            lblCorpLocation.Text = "Palo Alto, CA";
        }

        private void btnMicrosoft_Click(object sender, EventArgs e)
        {
            lblLogo.ImageIndex = 4;
            lblCorpName.Text = "Microsoft";
            lblCorpLocation.Text = "Redmond, WA";
        }

        private void btnSMCC_Click(object sender, EventArgs e)
        {
            lblLogo.ImageIndex = 5;
            lblCorpName.Text = "South Mountain Community College";
            lblCorpLocation.Text = "Phoenix, AZ";
        }
    }
}
